module.exports = {
    apps: [
      {
        name: "MAIN",
        namespace: "acerhizmq",
        script: 'ozi.js',
        watch: false,
        exec_mode: "cluster",
        max_memory_restart: "1G",
        cwd: "./Acer-Bots/Main",
        output: '../../Logger/[1]out.log',
        error: '../../Logger/[2]error.log',
        log: '../../Logger/[3]combined.outerr.log'
      },
      {
        name: "BACKUP",
        namespace: "acerhizmq",
        script: 'ozi.js',
        watch: false,
        exec_mode: "cluster",
        max_memory_restart: "1G",
        cwd: "./Acer-Bots/Backup",
        output: '../../Logger/[1]out.log',
        error: '../../Logger/[2]error.log',
        log: '../../Logger/[3]combined.outerr.log'
      },
      {
        name: "DESTEK",
        namespace: "acerhizmq",
        script: 'ozi.js',
        watch: false,
        exec_mode: "cluster",
        max_memory_restart: "1G",
        cwd: "./Acer-Bots/Destek",
        output: '../../Logger/[1]out.log',
        error: '../../Logger/[2]error.log',
        log: '../../Logger/[3]combined.outerr.log'
      },
      {
        name: "GUARD",
        namespace: "acerhizmq",
        script: 'lywacer.js',
        watch: false,
        exec_mode: "cluster",
        max_memory_restart: "1G",
        cwd: "./Acer-Bots/Guard",
        output: '../../Logger/[1]out.log',
        error: '../../Logger/[2]error.log',
        log: '../../Logger/[3]combined.outerr.log'
      },
    ]
  };