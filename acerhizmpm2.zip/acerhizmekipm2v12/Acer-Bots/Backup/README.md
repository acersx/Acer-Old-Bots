# Ozi Backup

- 70 Star olunca kullanıcı token özellik eklerim starlarınızı bekliyorum yeni github hesabım.
- Sizlerle geliştirmiş olduğum backup botlarından biriyle tanıştırmak istiyorum.. 
- Rol/Kanal Veri Kayıt ve tekrar oluşturma özelliklerine sahip gelişmiş bir backup bot.

# Yapmanız gereken adımlar

- Botumda bulunan jaylen.json kısmını doldurduktan sonra modüllerin yüklenmesi için npm i yapabilirsiniz botunuz hazır esenlikle kalın.

# Not 

- Emojinin ismi green kalmalıdır sunucunuzda da ayarlarsınız tepkiye basarsanız algılamaz yoksa

![image](https://user-images.githubusercontent.com/92666466/150602952-514dcf61-e12c-43d1-8184-b779797a4660.png) 
![image](https://user-images.githubusercontent.com/92666466/150219390-013f979d-64b4-4030-b427-ce3995b85e3f.png)
![image](https://user-images.githubusercontent.com/92666466/150219522-db85d0d8-9b09-44af-92b2-7273cd8f01bf.png)
![image](https://user-images.githubusercontent.com/92666466/150219413-92d74869-9a1e-491c-953b-78ef243dbc17.png)
![image](https://user-images.githubusercontent.com/92666466/149847028-bebdcd6b-b460-4f31-9a2d-8c748439e5d1.png)
![image](https://user-images.githubusercontent.com/92666466/148685686-2d4ba20b-b3e6-4e63-9ad5-3f8a160f7f14.png)
![image](https://user-images.githubusercontent.com/92666466/148685696-2be3327e-196b-4dfd-842f-937e344a92e1.png)
![image](https://user-images.githubusercontent.com/92666466/143085087-54b461fe-526d-4e48-9bb7-497b8a444511.png)
![image](https://user-images.githubusercontent.com/92666466/143085098-f153f296-6c92-4c87-9daa-df4cb5930d9b.png)
![image](https://user-images.githubusercontent.com/92666466/143085113-22289ea1-0e99-4a84-95de-54b6da12ecd7.png)
![image](https://user-images.githubusercontent.com/92666466/143085125-1503cd4e-c3c0-4503-9172-1e315c578776.png)
![image](https://user-images.githubusercontent.com/92666466/143085137-4703e78b-d365-4d33-aa65-c9a610e04d67.png)
![image](https://user-images.githubusercontent.com/92666466/143087025-572d7f7f-653b-4373-9eb5-85b16c1621c1.png)
![image](https://user-images.githubusercontent.com/92666466/143089451-765b4551-0752-4f4b-95ca-98ce79cdb55a.png)
