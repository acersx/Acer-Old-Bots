# Ozi Bots

- Testleri yapılmıştır. Hiçbir hatası bulunmamaktadır starlarınızı bekliyorum yeni github hesabım.
- Sizlerle geliştirmiş olduğum botlardan biriyle tanıştırmak istiyorum.. 
- Invite, Moderasyon, Butonlu Register /Oto Register, Stats, Buton sistemleri.

# Yapmanız gereken adımlar

- Config vesaire ayarladıktan sonra baslatmaya geldik npm i yapıyoruz ardından axios modülü yüklenmediği için npm i axios yapiyoruz eğer canvas yüklenmezse bazılarında hata oluyomus npm i canvas yapabilirsiniz botunuz hazır esenlikle kalın.

Not: Yeni Eklediğim LeaderBoard Güncelleme 

bak bı tane leaderboard kanal aç 
oranın ıd alttakı 2 tanesıne gır

    "ChatLeaderBoard": "915725828451606598",
    "VoiceLeaderBoard": "915725828451606598", 

leaderboard kanalında bot ownerı 2 tane .say atsın sırasıyla 
bot 2 tane embedlı say komutu atar bu botun attıklarının mesaj ıdsı lazım bıze
onların ıd yı sırayla alttakı 2 tane kısma gır

    "ChatMsgListID": "928301336158691348",
    "VoiceMsgListID": "928301342034907247",

Not: Aşağıdaki hata için veya welcome mesaj sorunu için .ytag ekle sil yapmanız gerekmektedir.

![image](https://user-images.githubusercontent.com/92666466/150496311-fa4725af-1d36-4004-b457-bcacfaee238b.png)

Not: Aşağıdaki rol menü sisteminde sol kısımdakiler emoji id isterseniz öyle kalabilir o kısım beğenmezseniz değişirsiniz, sağ kısımlarındaki ise rol idleridir.
Sırasıyla .menü <katılım/burc/oyun/renk/iliski> komutları kullanılırsa alttaki ss düzeninde olucaktır menü sistemi...

![image](https://user-images.githubusercontent.com/92666466/153303039-09fcfe31-9b33-4dea-a44a-d826c26a3bbc.png)
![image](https://user-images.githubusercontent.com/92666466/153302796-7f288c2a-2265-46cc-a553-a56e6c520794.png)
![image](https://user-images.githubusercontent.com/92666466/154173082-02e9c2ad-561a-4c88-a919-702ca5ae67a0.png)
![image](https://user-images.githubusercontent.com/92666466/150782527-f2fad818-da2a-4f8c-9f2a-4fc442fca688.png)
![image](https://user-images.githubusercontent.com/92666466/149677506-fa4dfc92-2815-40ec-bc9b-88675b96cc8a.png)
![image](https://user-images.githubusercontent.com/92666466/149625604-1a2b4481-0357-410d-8a01-4c9b209ed56f.png)
![image](https://user-images.githubusercontent.com/92666466/148831644-21111585-07a7-4871-8a4a-280c0cdad3e6.png)
![image](https://user-images.githubusercontent.com/92666466/147513264-07179317-e51a-43d1-bace-25d611c02c19.png)
![image](https://user-images.githubusercontent.com/92666466/145694537-015938d5-b724-47cc-b93a-bb63d95288fe.png)
![image](https://user-images.githubusercontent.com/92666466/144712851-feffdc3d-46d7-4bfc-addb-043bc4d6acba.png)
![image](https://user-images.githubusercontent.com/92666466/141508588-efd16297-700d-41af-9a64-a5f14f0316b3.png)
![image](https://user-images.githubusercontent.com/92666466/148201034-4527c526-7047-40f8-8e93-ad9a5379f1dd.png)
![image](https://user-images.githubusercontent.com/92666466/141027606-097f7300-47f4-42d4-a230-42faa1c12546.png)
![image](https://user-images.githubusercontent.com/92666466/141028898-ef3e2cad-7209-415a-8a84-201c6e976f9a.png)
![image](https://user-images.githubusercontent.com/92666466/139575506-c3d8b1cd-dab1-4c4a-8fc0-89e52b1148df.png)
![image](https://user-images.githubusercontent.com/92666466/139575391-c1c267fe-eee9-41c0-b821-cf90ca1c8641.png)
![image](https://user-images.githubusercontent.com/92666466/139575398-a0863b73-e2f0-4982-901d-6fc223640dae.png)
![image](https://user-images.githubusercontent.com/92666466/139575436-b1a629cf-340f-47f2-bf70-cead3f3d49bc.png)
![image](https://user-images.githubusercontent.com/92666466/139575377-ade118e3-c9b5-4bc8-a3b4-447fdc6325e6.png)
![image](https://user-images.githubusercontent.com/92666466/139575560-f6cd46be-5f2f-42b6-adbf-079aa835da73.png)
![image](https://user-images.githubusercontent.com/92666466/139575586-93156301-2cc4-45c2-a167-b82d51fa846f.png)
![image](https://user-images.githubusercontent.com/92666466/140218451-006119ee-7a23-41ce-8f1d-bf8c42f0b560.png)
![image](https://user-images.githubusercontent.com/92666466/139575596-53f98cee-5570-4bff-ad13-20393edb2470.png)
![image](https://user-images.githubusercontent.com/92666466/139575362-1562a395-5352-4528-b336-5400ef7abe11.png)
![image](https://user-images.githubusercontent.com/92666466/149665315-df680409-b4eb-44a6-bb93-f1fb10216f83.png)
![image](https://user-images.githubusercontent.com/92666466/139575381-c6cef99a-3dd2-4c43-b208-e7faa3233774.png)
![image](https://user-images.githubusercontent.com/92666466/139575656-0f8e35da-e696-4a6a-a3c7-5342af53de8d.png)
![image](https://user-images.githubusercontent.com/92666466/139575672-a7f84db7-98af-46c5-9f37-b2dbfc5fd729.png)

Thearkxd ve Aris'e codeları için tesekkürler...

