const { Client, Collection, Discord } = require("discord.js");
const client = (global.client = new Client({ fetchAllMembers: true }));
//RANK KISMI//
client.ranks = [
    { role: "899273632650510351", coin: 2000 },
    { role: "899273632650510352", coin: 3000 },
    { role: "899273632650510353", coin: 4000 },
    { role: "899273632650510354", coin: 5000 },
    { role: "899273632650510355", coin: 6000 },
    { role: "899273632663105586", coin: 7000 },
    { role: "899273632663105587", coin: 8000 },
    { role: "899273632663105589", coin: 9000 },
    { role: "899273632663105590", coin: 15000 },
    { role: "899273632663105591", coin: 11000 },
    { role: "899273632663105592", coin: 17000 },
    { role: "899273632663105593", coin: 20000 },
    { role: "899273632679866395", coin: 22000 },
    { role: "899273632679866396", coin: 25000 },
    { role: "899273632696631358", coin: 28000 },
    { role: "899273632696631359", coin: 40000 },
    ]