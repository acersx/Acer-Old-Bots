const penals = require("../schemas/penals");
const voiceInfo = require("../schemas/voiceInfo")
const conf = require("../configs/sunucuayar.json");
module.exports = async (oldState, newState) => {
  if (oldState.channelID && !newState.channelID) return;
  const finishedPenal = await penals.findOne({ guildID: newState.guild.id, userID: newState.id, type: "VOICE-MUTE", removed: false, temp: true, finishDate: { $lte: Date.now() } });
  if (finishedPenal) {
    if (newState.serverMute) newState.setMute(false);
    await newState.member.roles.remove(conf.voiceMute);
    finishedPenal.active = false;
    finishedPenal.removed = true;
    await finishedPenal.save();
  }

  const activePenal = await penals.findOne({ guildID: newState.guild.id, userID: oldState.id, type: "VOICE-MUTE", active: true });
  if (activePenal) {
    if (!newState.serverMute) newState.setMute(true);
    if (!conf.voiceMute.some((x) => newState.member.roles.cache.has(x))) newState.member.roles.add(conf.voiceMute);
  }
  if (!oldState.channelID && newState.channelID) await voiceInfo.findOneAndUpdate({ userID: newState.id }, { $set: { date: Date.now() } }, { upsert: true });
  else if (oldState.channelID && !newState.channelID) await voiceInfo.deleteOne({ userID: oldState.id });


 module.exports = async (oldState, newState) => {
  let embed = new MessageEmbed()
  if ((oldState.member && oldState.member.user.bot) || (newState.member && newState.member.user.bot)) return;
  if(newState.member.hasPermission('ADMINISTRATOR') || newState.member.roles.cache.has(config.boosterRolu)) return;
  let log = newState.guild.channels.cache.get(conf.vkickLogChannel)
  let chat = newState.guild.channels.cache.get(conf.chatChannel)
  if (oldState.member.nickname) {
      let ageLimit = oldState.member.nickname.includes(" ") && oldState.member.nickname.split("   ")[1] || 0
  if (!oldState.channelID && newState.channelID) {
      if (newState.channel && newState.channel.name.includes("+18")) {
          if(ageLimit < conf.minyas) {
              await log.send(`${newState.member}`, {embed: embed.setDescription(`${newState.member} üyesi **18 yaşından** küçük olmasına rağmen +18 kanallara giriş yaptığından dolayı \`${newState.channel.name}\` isimli kanaldan atıldı!`)})
              await chat.send(`${newState.member} **18 yaşından** küçük olduğun için \`${newState.channel.name}\` isimli kanaldan atıldın!`).catch(e => { });
              await newState.member.voice.kick().catch(e => { });
          }
      }
  }
  if (oldState.channelID && newState.channelID) {
      if (newState.channel && newState.channel.name.includes("+18")) {
          if(ageLimit < conf.minyas) {
              await log.send(`${newState.member}`, {embed: embed.setDescription(`${newState.member} üyesi **18 yaşından** küçük olmasına rağmen +18 kanallara giriş yaptığından dolayı \`${newState.channel.name}\` isimli kanaldan atıldı!`)})
              await chat.send(`${newState.member} **18 yaşından** küçük olduğun için \`${newState.channel.name}\` isimli kanaldan atıldın!`).catch(e => { });
              await newState.member.voice.kick().catch(e => { });
          }
      }
  }
}

}
};

module.exports.conf = {
  name: "voiceStateUpdate",
};
