const settings = require("../configs/settings.json");
let guild = settings.guildID
const client = global.client;
const conf = require ("../configs/sunucuayar.json");
const channel = client.channels.cache.get(conf.invLogChannel);
module.exports = async (invite) => {
  const gi = client.invites.get(invite.guild.id);
  gi.set(invite.code, invite);
  client.invites.set(invite.guild.id, gi);
  channel.wsend(`${member.displayName} üyesi yeni bir davet oluşturdu!`)
};

module.exports.conf = {
  name: "inviteCreate",
};