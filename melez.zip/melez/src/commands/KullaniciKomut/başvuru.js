const Discord = require("discord.js");
const Config = require("../../configs/sunucuayar.json");
const moment = require("moment")
const { green } = require("../../configs/emojis.json");
module.exports = {
    conf: {
      aliases: ["başvuru","başvur"],
      name: "başvur",
      help: "başvue"
    },
    async run(message, args, perm) {
      if (message.author.bot || message.channel.id !== Config.yetkiLog) return;
     // if (message.content !== conf.command) return message.delete();
      if (message.guild.channels.cache.filter((x) => x.parentID === Config.başvuruParent).size >= 7) {
        //message.react(conf.cross);
        return message.channel.send(`${message.author.toString()}, Şuanda fazla kişi için başvuru kanalı açtım lütfen daha sonra dene!`).then((x) => x.delete({ timeout: 20000 }));
      }
      
      message.react(green);
      message.channel.send(`
      ${message.author.toString()}, Sol taraftaki başvuru kategorisinde sana özel oda açıp seni etiketledim. Sana soracağımız soruları zamanında cevaplaman gerekiyor.
      `).then((x) => x.delete({ timeout: 10000 }));
      
      let modRole = message.guild.roles.cache.find(r => r.id === Config.yetkilialım);

      const regex = /[a-zA-Z0-9]{1,20}/g;
      const username = message.author.username.match(regex)[0];
      const newChannel = await message.guild.channels.create(username, {
        topic: message.author.id,
        type: 'text',
        parent: (Config.başvuruParent),
        permissionOverwrites: [
            { id: message.guild.id, deny: ['VIEW_CHANNEL'] },
            { id: modRole.id, allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'] },
            { id: message.author.id, allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'] }
        ]
      });
    
      
    
        newChannel.overwritePermissions([{ id: message.author.id, allow: ["SEND_MESSAGES"] }]);
        //newMessage.delete();
        await newChannel.send(`${message.author.toString()} Sistemimize başvurdun, öncelikle ismini öğrenebilir miyim?`);
        const name = await newChannel.awaitMessages((m) => m.author.id === message.author.id, {
          max: 1,
          time: 1000 * 60 * 5,
          errors: ["time"]
        }).catch(() => newChannel.delete());
        await newChannel.send(`Memnun oldum ${name.first().content}, Peki ya yaşınız?`);
        const age = await newChannel.awaitMessages((m) => m.author.id === message.author.id, {
          max: 1,
          time: 1000 * 60 * 5,
          errors: ["time"]
        }).catch(() => newChannel.delete());
        await newChannel.send(`${name.first().content}, Şimdi bize Discord'da günde kaç saat aktif olduğunu söyleyebilir misin?`);
        const activity = await newChannel.awaitMessages((m) => m.author.id === message.author.id, {
          max: 1,
          time: 1000 * 60 * 5,
          errors: ["time"]
        }).catch(() => newChannel.delete());
        await newChannel.send(`Bize taglı üye, public odalarda ses aktifliği kasacak user veya invite sağlayabilir misin?`);
        const invite = await newChannel.awaitMessages((m) => m.author.id === message.author.id, {
          max: 1,
          time: 1000 * 60 * 5,
          errors: ["time"]
        }).catch(() => newChannel.delete());
        await newChannel.send(`Başvurunu başarıyla aldım ${name.first().content}, En kısa zamanda bilgilerini inceleyip sana döneceğiz. Başvurun onaylanırsa veya reddedilerse sana özelden mesaj atacağım. Eğer DM'n kapalıysa seni kanala etiketleyip bilgilendireceğim.`);
     
        const embed = new Discord.MessageEmbed()
          .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true, size: 2048 }))
          .setThumbnail(message.author.avatarURL({ dynamic: true, size: 2048 }))
          .setTitle("Cevap Bekliyor...")
          .setColor("BLUE")
          .setDescription(`
      **Başvuruda bulunan:** ${message.member.toString()} \`(${message.author.username} - ${message.author.id})\`
      **Başvuru tarihi:** ${moment().format("LLL")}
      **İsim:** ${name.first().content}
      **Yaş:** ${age.first().content}
      **Aktiflik Süresi:** ${activity.first().content}
      **Günlük İnvite Durumu:** ${invite.first().content}
          `);
        await message.guild.channels.cache.get(Config.yetkiLog).send(embed).then(async can => {

let reactions = ['✅', '❌'];
for(let reaction of reactions) await can.react(reaction);

const first= can.createReactionCollector((reaction, user) => reaction.emoji.name == "✅" && user.id == message.author.id, { time: 30000 });
                const second = can.createReactionCollector((reaction, user) => reaction.emoji.name == "❌" && user.id == message.author.id, { time: 30000 });

first.on('collect', async reaction => {
  can.edit(new Discord.MessageEmbed()
  .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true, size: 2048 }))
  .setThumbnail(message.author.avatarURL({ dynamic: true, size: 2048 }))
  .setTitle("Cevap Bekliyor...")
  .setColor("BLUE")
  .setDescription(`**ONAYLANDI!!!\n\n**Başvuruda bulunan:** ${message.member.toString()} \`(${message.author.username} - ${message.author.id})\`
          **Başvuru tarihi:** ${moment().format("LLL")}
          **İsim:** ${name.first().content}
          **Yaş:** ${age.first().content}
          **Aktiflik Süresi:** ${activity.first().content}
          **Günlük İnvite Durumu:** ${invite.first().content}`));
          message.guild.member(message.author).roles.add(Config.yetkiRolleri)})
  message.author.send(`Sunucumuza yetkililik başvurun kabul edildi. Yetki permlerini verdim.`).catch(err => {message.channel.send(`${message.author} Sunucumuza yetkili başvurun kabul edildi. Yetki permlerini verdim.`)})
second.on('collect', async reaction => {
  can.edit(new Discord.MessageEmbed()
  .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true, size: 2048 }))
  .setThumbnail(message.author.avatarURL({ dynamic: true, size: 2048 }))
  .setTitle("Cevap Bekliyor...")
  .setColor("BLUE")
  .setDescription(`**REDDEDİLDİ!!!\n\n**Başvuruda bulunan:** ${message.member.toString()} \`(${message.author.username} - ${message.author.id})\`
          **Başvuru tarihi:** ${moment().format("LLL")}
          **İsim:** ${name.first().content}
          **Yaş:** ${age.first().content}
          **Aktiflik Süresi:** ${activity.first().content}
          **Günlük İnvite Durumu:** ${invite.first().content}`));
         message.author.send(`Üzgünüm sunucumuza yetkililik başvurun reddedildi.`).catch(err => {message.channel.send(`${message.author} Üzgünüm sunucumuza yetkililik başvurun reddedildi.`)})
        })
first.on('end', async reaction => {
  can.edit(new Discord.MessageEmbed()
  .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true, size: 2048 }))
  .setThumbnail(message.author.avatarURL({ dynamic: true, size: 2048 }))
  .setTitle("Cevap Bekliyor...")
  .setColor("BLUE")
  .setDescription(`**SÜRESİ DOLDU!!!\n\n**Başvuruda bulunan:** ${message.member.toString()} \`(${message.author.username} - ${message.author.id})\`
          **Başvuru tarihi:** ${moment().format("LLL")}
          **İsim:** ${name.first().content}
          **Yaş:** ${age.first().content}
          **Aktiflik Süresi:** ${activity.first().content}
          **Günlük İnvite Durumu:** ${invite.first().content}`));
      message.author.send(`Üzgünüm sunucumuza yetkililik başvuruna yetkililer herhangi bir cevap vermediği için süresi doldu.`).catch(err => {message.channel.send(`${message.author} Üzgünüm sunucumuza yetkililik başvuruna yetkililer herhangi bir cevap vermediği için süresi doldu.`)})
          
  
          
})

})

       

        setTimeout(() => {
          newChannel.delete();
        }, 15000);
      }
      }