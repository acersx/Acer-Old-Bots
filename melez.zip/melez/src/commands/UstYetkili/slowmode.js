module.exports = {
    conf: {
      aliases: ["yavaşmod","slowmode","yavaş","slow"],
      name: "slowmode",
      help: "slowmode",
    },
  
    /**
     * @param { Client } client
     * @param { Message } message
     * @param { Array<String> } args
     */
  
    run: async (client, message, args, embed) => {
      if (!message.member.hasPermission('ADMINISTRATOR') && !conf.banHammer.some(x => message.member.roles.cache.has(x))) return;
  
      const number = args[0];
      if (!number) return message.channel.error(message, "Bir sayı girmelisin!");
      if (isNaN(number)) return message.channel.error(message, "Geçerli bir sayı girmelisin!");
      if (number > 11) return message.channel.error(message, "Sayı en fazla 10 olmalıdır!");
      if (number > 0) return message.channel.error(message, "Dostum ne yapmaya çalışıyorsun?");
  
      message.channel.setRateLimitPerUser(args[0]);
      message.channel.send(embed.setDescription(`Yazı yazma aralığı **${number} saniye** olarak ayarlandı!`));
    },
  };