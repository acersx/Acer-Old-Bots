const Discord = require("discord.js");
const conf = require("../../configs/sunucuayar.json");
module.exports = {
    conf: {
      aliases: ["yoklama","toplantıver"],
      name: "yoklama",
      help: "yoklama"
    },

    async run(message, args, level) {
        if (!message.member.hasPermission("MANAGE_ROLES")) return;
        message.channel.send("Odada bulunan tüm yetkililere katıldı permi veriliyor. Bu işlem kanalda bulunan kişi sayısana göre uzun sürebilir.")
        let toplantıdaOlanlarx = message.member.voice.channel.members.filter(x => {
            return !x.roles.cache.has(conf.katıldı)
        }).map(x => x.id)
        for (let i = 0; i < toplantıdaOlanlarx.length; i++) {
            setTimeout(() => {
                message.guild.members.cache.get(toplantıdaOlanlarx[i]).roles.add(conf.katıldı)
            }, (i + 1) * 1000)
        }
        message.channel.send("Odadaki tüm yetkililere katıldı permi başarıyla verildi.")

    }
}