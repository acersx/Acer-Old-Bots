const { ownıy, yıydıy, ciyo} = require("../../configs/sunucuayar.json")
const moment = require("moment");
const Discord = require("discord.js");
const { green, red } = require("../../configs/emojis.json")
moment.locale("tr")
module.exports = {
    conf: {
      aliases: ["ohal","koruma"],
      name: "ohal",
      owner: true,
      enabled: true
    },
    run: async (client, message, args, embed) => {
            if(!args[0]){
                message.react(red)
                message.channel.send(embed.setDescription(`Bir argüman belirtmelisin! \`aç - kapat\``)).then(x=>x.delete({timeout:5000}))
                }
                if(args[0] == "aç") {
                const yetki1 = message.guild.roles.cache.find(r => r.id === ownıy);//#OWNER
                yetki1.setPermissions(0);
                const yetki2 = message.guild.roles.cache.find(r => r.id === ciyo);//#Ceo
                yetki2.setPermissions(0);
                const yetki3 = message.guild.roles.cache.find(r => r.id === yıydıy);//#Yıldız
                yetki3.setPermissions(0);
                let isim = `${message.guild.name} #OHAL`
                message.guild.setName(isim)
                message.reply(`Başarılı bir şekilde ohal modu aktif edildi.`)
                message.react(green)
                console.log(`${message.author.tag} (${message.author.id}) tarafından ${moment(message.createdAt).format("lll")} zamanında ohal aktif edildi.`)   
        
             }
        
        
               
          
                if(args[0] == "kapat") {
                message.channel.send(`Ohal kapatıldı! Rollerin yetkileri yüklendi!`)
                message.react(green)
                message.guild.setName(message.guild.setName(message.guild.name.replace('#OHAL', '')))
                const yetki1 = message.guild.roles.cache.find(r => r.id === ownıy);//#Owner
                yetki1.setPermissions(4592763008);
                const yetki2 = message.guild.roles.cache.find(r => r.id === ciyo);//#Ceo    
                yetki2.setPermissions(4324327554);
                const yetki3 = message.guild.roles.cache.find(r => r.id === yıydıy);//#Yıldız
                yetki3.setPermissions(4324327424);
                console.log(`${message.author.tag} (${message.author.id}) tarafından ${moment(message.createdAt).format("lll")} zamanında ohal deaktif edildi.`)   
    }
    }}