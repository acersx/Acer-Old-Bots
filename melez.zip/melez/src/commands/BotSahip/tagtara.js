const Discord = require('discord.js')
module.exports = {
    conf: {
      aliases: ['tagtara', 'taratag', 'tagbul'],
      name: "tagtara",
      owner: true,
    },

run: async = (client, message, args) => {
  
  if (!message.member.hasPermission("ADMINISTRATOR")) return message.reply(`Bu komutu kullanabilmek için kurucu olmalısın!`);
  const tag = args.slice(0).join(' ');
if(!tag) return message.reply(`:warning: Bir Tag Girmelisiniz Örnek Kullanım; .tagtara #0001`)
  const uyeask = message.guild.members.filter(member => member.user.username.includes(tag));
    const embed = new Discord.RichEmbed()
        .addField(`Kullanıcı Adında ${tag} Tagı Olan Kullanıcılar`, uyeask.map(member => `${member} = ${member.user.tag}`).join("\n") || `Kimsenin kullanıcı Adında \`${tag}\` Tagı Bulunmuyor.`)
        .setColor("RANDOM")
    message.channel.send({embed})
}
}